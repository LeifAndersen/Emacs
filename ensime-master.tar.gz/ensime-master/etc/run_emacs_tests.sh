#!/bin/bash
emacs --no-init-file --load .emacs_test.el